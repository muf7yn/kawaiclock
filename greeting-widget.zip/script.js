function getSoftGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Hey Muffyn, it’s a sunny day~ ☀️";
  if (hour < 17) return "Hope your afternoon’s gentle, Muffyn~ 🌤";
  if (hour < 20) return "Evening’s calm, Muffyn~ 🌆";
  return "Night’s soft and starry, Muffyn~ 🌙";
}

function getDate() {
  const today = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  return today.toLocaleDateString(undefined, options);
}

document.getElementById("greeting").textContent = getSoftGreeting();
document.getElementById("date").textContent = getDate();
